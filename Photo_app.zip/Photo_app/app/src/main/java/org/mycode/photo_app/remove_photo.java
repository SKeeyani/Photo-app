package org.mycode.photo_app;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import org.mycode.photo_app.R;

class RemovePhotoOrArtist extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_remove_photo_or_artist);
    }
}
