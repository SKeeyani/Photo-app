package org.mycode.photo_app;

import android.widget.Button;
import android.widget.GridView;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class view_photo extends AppCompatActivity {
    private ArrayList<Artist> artists;

    private ArrayList<Photograph>photoList = new ArrayList<>();

    private Spinner artistNameSpinner;
    private Button searchBtn;
    private GridView photoGridView;



}
